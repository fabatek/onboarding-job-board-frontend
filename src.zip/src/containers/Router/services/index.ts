export const routes = {
  ROOT: "/",
};
